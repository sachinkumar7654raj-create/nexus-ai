package com.nexus.personalasistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 40, 28, 28)
            setBackgroundColor(0xFF10131A.toInt())
        }
        val title = TextView(this).apply {
            text = "NEXUS AI"
            textSize = 30f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "नमस्ते! Mic दबाकर बोलो: ऐप खोलो, WhatsApp खोलो, या कोई सवाल पूछो।"
            textSize = 17f
            setTextColor(0xFFE0E4EF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 28)
        }
        val mic = Button(this).apply {
            text = "🎙 बोलो / Speak"
            setOnClickListener { listen() }
        }
        val whatsapp = Button(this).apply {
            text = "WhatsApp संदेश लिखें"
            setOnClickListener {
                val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/?text=" + Uri.encode("नमस्ते!")))
                startActivity(i)
            }
        }
        val help = TextView(this).apply {
            text = "\nअभी उपलब्ध: आवाज़ पहचानना, ऐप खोलना, WhatsApp में संदेश तैयार करना और जवाब बोलकर सुनाना।\n\nनोट: यह शुरुआती संस्करण है। सामान्य AI चैट और दूसरी ऐप में अपने-आप टैप/टाइप करने के लिए आगे सुरक्षित सेटअप चाहिए।"
            textSize = 14f
            setTextColor(0xFFB9C1D4.toInt())
        }
        root.addView(title)
        root.addView(status)
        root.addView(mic)
        root.addView(whatsapp)
        root.addView(help)
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("इस फोन पर आवाज़ पहचान उपलब्ध नहीं है।")
            return
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "NEXUS AI को बोलें")
        }
        try {
            startActivityForResult(i, 20)
        } catch (_: Exception) {
            say("आवाज़ पहचान शुरू नहीं हो पाई।")
        }
    }

    @Deprecated("Deprecated by Android but compatible with Android 12")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 20 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) handleCommand(spoken)
        }
    }

    private fun handleCommand(command: String) {
        status.text = "आपने कहा: $command"
        val c = command.lowercase(Locale.ROOT)
        when {
            c.contains("whatsapp") && (c.contains("खोल") || c.contains("open")) -> {
                val launch = packageManager.getLaunchIntentForPackage("com.whatsapp")
                    ?: packageManager.getLaunchIntentForPackage("com.whatsapp.w4b")
                if (launch != null) startActivity(launch) else say("WhatsApp नहीं मिला।")
            }
            c.contains("मैसेज") || c.contains("message") -> {
                val message = command.substringAfter("कि", "").ifBlank { "नमस्ते!" }
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/?text=" + Uri.encode(message))))
                say("WhatsApp में संदेश तैयार कर रहा हूँ। भेजने से पहले जाँच लेना।")
            }
            c.startsWith("open ") || c.startsWith("खोलो ") || c.startsWith("खोल ") -> {
                val name = command.removePrefix("open ").removePrefix("खोलो ").removePrefix("खोल ").trim().lowercase(Locale.ROOT)
                val apps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
                val match = apps.firstOrNull { packageManager.getApplicationLabel(it).toString().lowercase(Locale.ROOT).contains(name) }
                val launch = match?.let { packageManager.getLaunchIntentForPackage(it.packageName) }
                if (launch != null) {
                    startActivity(launch)
                    say("ऐप खोल रहा हूँ।")
                } else say("यह ऐप नहीं मिला। ऐप का नाम अंग्रेज़ी में बोलकर देखो।")
            }
            else -> say("मैंने सुना: $command। अभी इस शुरुआती संस्करण में सामान्य AI जवाब जोड़ने के लिए AI सेवा की सुरक्षित कनेक्शन सेटिंग बाकी है।")
        }
    }

    private fun say(text: String) {
        status.text = text
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nexus")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN")
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
