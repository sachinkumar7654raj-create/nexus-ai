# NEXUS AI starter Android project

This is a starter app, not a complete Jarvis-like assistant. It supports voice recognition through Android's speech-recognition intent, speech output, launching some installed apps, and preparing a WhatsApp message for review.

## Build
Use Android Gradle Plugin 8.5.2, Gradle 8.7, and JDK 17. In a cloud runner, run `gradle assembleDebug` from this project root. The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

The app does not include a general-purpose LLM connection or accessibility automation. Add those deliberately and securely in a later version. No API key is included.
